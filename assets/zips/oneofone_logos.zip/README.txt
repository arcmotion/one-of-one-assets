One of One brand files

PNG: slides, documents, email. Files ending in _large are for posters and big screens.
SVG: websites and designers. Scales to any size.
PDF: printers.

Use a dark logo on light backgrounds and a light logo on dark backgrounds.
Keep clear space around the logo. Do not stretch, rotate, recolour or add effects.
